package org.springframework.test.context.junit4;

public @interface SpringJUnit4ClassRunner {

}
